package testng.maven.project;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class FirstTestClass {
  
  @Test
  public void firstMethod() {
	  System.out.println("this is firstMethod Test method");
  }
	
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("this is beforeMethod method");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("this is afterMethod method");
  }

}
