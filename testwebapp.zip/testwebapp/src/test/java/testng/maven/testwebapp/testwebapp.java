package testng.maven.testwebapp;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class testwebapp {

	private WebDriver driver = null;

	@Test(groups = { "Smoke", "Functional" })
	public void testCase1() {
		driver.findElement(By.xpath("/html[1]/body[1]/header[1]/nav[1]/div[1]/ul[1]/li[3]/a[1]/span[1]")).click();

		WebElement aboutlink = driver.findElement(By.xpath("//h2[normalize-space()='Selenium IDE']"));

		String dowloadtitle = aboutlink.getText();
		System.out.println(" current page is : " + dowloadtitle);

		assertEquals(dowloadtitle, "Selenium IDE");
	}

	@SuppressWarnings("deprecation")
	@BeforeClass(alwaysRun = true)
	public void beforeClass() {
//	  System.setProperty("webdrive.chrome.driver", "C:\\Users\\hackrec\\Documents\\TestNG-workshop\\testwebapp\\drivers\\chrome.exe");
//	  driver = new ChromeDriver();

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

//	  WebDriverManager.edgedriver().setup();
//	  driver = new EdgeDriver();

		driver.manage().window().maximize();
		// driver.manage().deleteAllCookies();

		driver.get("https://www.selenium.dev/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@AfterClass(alwaysRun = true)
	public void afterClass() {
		driver.close();
	}

}
