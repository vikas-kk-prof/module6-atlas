package testng.maven.testwebapp;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderExample {

	@DataProvider(name="dataprovider_test")
	public Object[][] dataProviderMethod(){
		return new Object[][] {{"Vikas"}, {"Vikram"}};
	}
	
	@Test(dataProvider = "friendsNameList", dataProviderClass = DataProviders.class)
	public void printNames(String values) {
		System.out.println("Name of Friends :" + values);
	}
	
	@Test(dataProvider = "userLogindetails", dataProviderClass = DataProviders.class)
	public void printUserLoginDetails(String userName, String userEmail, String userPass) {
		System.out.println("Name of user :" + userName);
		System.out.println("Email id of user: "+ userEmail);
		System.out.println("Password of email: "+ userPass);
	}
}
