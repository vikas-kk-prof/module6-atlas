package testng.maven.testwebapp;

import org.testng.annotations.DataProvider;

public class DataProviders {

	@DataProvider(name="friendsNameList")
	public Object[][] friendsNameList(){
		return new Object[][] {{"Vikas"}, {"Vikram"}};
	}
	
	@DataProvider(name="orderList")
	public Object[][] orderList(){
		return new Object[][] {{"pencile box"}, {"black pen's set"}};
	}
	
	@DataProvider(name="userLogindetails")
	public Object[][] userLogindetails(){
		return new Object[][] {
			{"Vikas kumar", "Vikaskpro7@gmail.com", "password"}, 
			{"Vikram", "Vikram@gmail.com", "VikramPassword123"}
		};
	}
}
