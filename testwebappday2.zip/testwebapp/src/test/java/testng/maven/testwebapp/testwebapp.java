package testng.maven.testwebapp;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class testwebapp {

	private WebDriver driver = null;

	@Test
	public void testCase1() {
		driver.findElement(By.xpath("/html[1]/body[1]/header[1]/nav[1]/div[1]/ul[1]/li[3]/a[1]/span[1]")).click();

		WebElement aboutlink = driver.findElement(By.xpath("//h2[normalize-space()='Selenium IDE']"));

		String dowloadtitle = aboutlink.getText();
		System.out.println(" current page is : " + dowloadtitle);

		assertEquals(dowloadtitle, "Selenium IDE");
	}

	@SuppressWarnings("deprecation")
	@BeforeClass
	@Parameters({"browser", "syslog"}) 
	public void beforeClass(String browser,String syslog) {
//	  System.setProperty("webdrive.chrome.driver", "C:\\Users\\hackrec\\Documents\\TestNG-workshop\\testwebapp\\drivers\\chrome.exe");
//	  driver = new ChromeDriver();
		
//		  WebDriverManager.edgedriver().setup();
//		  driver = new EdgeDriver();
		
		if(browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}else if(browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}else if(browser.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}

		driver.manage().window().maximize();
		// driver.manage().deleteAllCookies();

		driver.get("https://www.selenium.dev/");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println(syslog);
	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}

}
